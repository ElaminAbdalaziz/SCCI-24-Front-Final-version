// loader
function goToLanding() {
  window.location.href = "landing.html";
}

setTimeout(goToLanding, 2000);
// end loader
